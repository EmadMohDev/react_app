const memberInfo =
[
    {id:1, img:'/images/01.jpg',    name:'Walter White',    position:'Bryan Cranston',      phone:'+49 12345678',   email:'walter@b-bad.com',   website:'walterwhite.com'   },
    {id:2, img:'/images/02.jpg',    name:'Jesse Pinkman',   position:'Aaron Paul',          phone:'+49 12345678',   email:'jesse@b-bad.com',    website:'jessepinkman.com'  },
    {id:3, img:'/images/03.jpg',    name:'Skyler White',    position:'Anna Gunn',           phone:'+49 12345678',   email:'skyler@b-bad.com',   website:'skylerwhite.com'   },
    {id:4, img:'/images/04.jpg',    name:'Gus Fring',       position:'Giancarlo Esposito',  phone:'+49 12345678',   email:'gus@b-bad.com'                                   },
    {id:5, img:'/images/05.jpg',    name:'Saul Goodman',    position:'Bob Odenkirk',        phone:'+49 12345678',   email:'saul@b-bad.com'                                  },
    {id:6, img:'/images/06.jpg',    name:'Hank Schrader',   position:'Dean Norris',         phone:'+49 12345678',   email:'hank@b-bad.com'                                  },
]

export default memberInfo