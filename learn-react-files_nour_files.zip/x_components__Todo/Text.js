import React from 'react'

function Text(){
    
    return(
        <p>Graphic and Web design are far more than a job for me. Thanks to my extensive technical knowledge.</p>
    );
}

export default Text;